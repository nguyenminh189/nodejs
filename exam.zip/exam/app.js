const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const app = express();
const port = 3000;

mongoose.connect('mongodb://localhost:27017/finalexam')
    .then(() => console.log('MongoDB connected...'))
    .catch(err => console.log(err));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.static('public'));

app.set('view engine', 'ejs');

const productSchema = new mongoose.Schema({
  ProductCode: String,
  ProductName: String,
  ProductDate: String,
  ProductOriginPrice: Number,
  Quantity: Number,
  ProductStoreCode: String
});

const Product = mongoose.model('Product', productSchema);

app.get('/', async (req, res) => {
  const products = await Product.find();
  res.render('index', { products });
});

app.post('/products', async (req, res) => {
  const { ProductCode, ProductName, ProductDate, ProductOriginPrice, Quantity, ProductStoreCode } = req.body;
  await Product.create({ ProductCode, ProductName, ProductDate, ProductOriginPrice, Quantity, ProductStoreCode });
  res.redirect('/');
});

app.delete('/products/:id', async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.redirect('/');
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});